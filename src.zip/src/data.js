const data =[
  {
    "_id": "5e69bc22f21432c93c804f76",
    "name": "Griffith Hays",
    "gender": "male"
  },
  {
    "_id": "5e69bc225f1b80d882f949b3",
    "name": "Cain Tanner",
    "gender": "male"
  },
  {
    "_id": "5e69bc22a66927e8b820ea36",
    "name": "Alford Hendricks",
    "gender": "male"
  },
  {
    "_id": "5e69bc22e1a946fdd1b2b9b1",
    "name": "Leigh Martinez",
    "gender": "female"
  },
  {
    "_id": "5e69bc223f5a99bd4cd1ac52",
    "name": "Jeanne Leblanc",
    "gender": "female"
  },
  {
    "_id": "5e69bc222ea274a5434c3053",
    "name": "Berta Pruitt",
    "gender": "female"
  },
  {
    "_id": "5e69bc22c8f4dc95dea28891",
    "name": "Harper Burke",
    "gender": "male"
  },
  {
    "_id": "5e69bc22804822bc894d9be6",
    "name": "Catherine Delacruz",
    "gender": "female"
  },
  {
    "_id": "5e69bc226a85e1d3f586e7ed",
    "name": "Jami Case",
    "gender": "female"
  },
  {
    "_id": "5e69bc22c8a6fc0cc02ff7e3",
    "name": "Effie Marquez",
    "gender": "female"
  },
  {
    "_id": "5e69bc221d851fcc26a7b6ee",
    "name": "Claudette Pace",
    "gender": "female"
  },
  {
    "_id": "5e69bc22e545f947c171c764",
    "name": "Ivy Patterson",
    "gender": "female"
  },
  {
    "_id": "5e69bc22acb6715435225db0",
    "name": "Hammond Dean",
    "gender": "male"
  },
  {
    "_id": "5e69bc224fa178067d1fce5b",
    "name": "Dorthy Avila",
    "gender": "female"
  },
  {
    "_id": "5e69bc2212eb69455492373e",
    "name": "Park Pacheco",
    "gender": "male"
  },
  {
    "_id": "5e69bc22035faac1c633b216",
    "name": "Letitia Blanchard",
    "gender": "female"
  },
  {
    "_id": "5e69bc22a36e1ffc087f1a85",
    "name": "Figueroa Bolton",
    "gender": "male"
  },
  {
    "_id": "5e69bc226f74921d2355bea5",
    "name": "Guerrero Stephens",
    "gender": "male"
  },
  {
    "_id": "5e69bc225ad19774e0588587",
    "name": "Jane Mcleod",
    "gender": "female"
  },
  {
    "_id": "5e69bc22276d4740d9da2b8b",
    "name": "Elvira Parker",
    "gender": "female"
  },
  {
    "_id": "5e69bc228450cda31830239c",
    "name": "Glover Floyd",
    "gender": "male"
  },
  {
    "_id": "5e69bc222be4da9d0a9846ef",
    "name": "Rosa Stevenson",
    "gender": "male"
  },
  {
    "_id": "5e69bc229dc4de0189fb3368",
    "name": "Petersen Buck",
    "gender": "male"
  },
  {
    "_id": "5e69bc2273de13834ba16408",
    "name": "Terrell Frederick",
    "gender": "male"
  },
  {
    "_id": "5e69bc22fd2df45ead3646cd",
    "name": "Brooks Bradley",
    "gender": "male"
  }
]
export default data